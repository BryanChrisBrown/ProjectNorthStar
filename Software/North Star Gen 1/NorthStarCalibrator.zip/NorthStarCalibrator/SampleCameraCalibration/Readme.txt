This is an example camera calibration that you can reference to see if the one you ended up with is reasonable.

This will not be a correct camera calibration for your device, but it can be helpful for testing.